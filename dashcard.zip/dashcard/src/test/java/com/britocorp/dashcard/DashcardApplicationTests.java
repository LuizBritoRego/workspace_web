package com.britocorp.dashcard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DashcardApplicationTests {

	@Test
	void contextLoads() {
	}

}
