package com.britocorp.dashcard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DashcardApplication {

	public static void main(String[] args) {
		SpringApplication.run(DashcardApplication.class, args);
	}

}
